const canvas = document.getElementById("coordinateCanvas");
const ctx = canvas.getContext("2d");

const form = document.getElementById("pointForm");
const yInput = document.getElementById("y");
const rInput = document.getElementById("r");
const errorMessage = document.getElementById("errorMessage");
const resultsBody = document.getElementById("resultsBody");

const STORAGE_KEY = "point-check-results";

function normalizeNumber(value) {
    return value.trim().replace(",", ".");
}

function isValidNumber(value) {
    return value !== "" && Number.isFinite(Number(value));
}

function getSelectedX() {
    const selected = document.querySelector('input[name="x"]:checked');
    return selected ? Number(selected.value) : null;
}

function validateY(value) {
    if (!isValidNumber(value)) {
        return "Y должен содержать число.";
    }

    const y = Number(value);
    if (y < -3 || y > 5) {
        return "Y должен находиться в диапазоне от -3 до 5.";
    }

    return "";
}

function validateR(value) {
    if (!isValidNumber(value)) {
        return "R должен содержать число.";
    }

    const r = Number(value);
    if (r < 1 || r > 4) {
        return "R должен находиться в диапазоне от 1 до 4.";
    }

    return "";
}

function validateForm() {
    const x = getSelectedX();
    const yValue = normalizeNumber(yInput.value);
    const rValue = normalizeNumber(rInput.value);

    if (x === null) {
        return "Выберите значение X.";
    }

    const yError = validateY(yValue);
    if (yError) {
        return yError;
    }

    const rError = validateR(rValue);
    if (rError) {
        return rError;
    }

    return "";
}

function pointIsInside(x, y, r) {
    const inRectangle =
        x >= 0 &&
        y >= 0 &&
        x <= r &&
        y <= r;

    const inTriangle =
        x <= 0 &&
        y >= 0 &&
        x >= -r / 2 &&
        y <= 2 * x + r;

    const inQuarterCircle =
        x >= 0 &&
        y <= 0 &&
        x * x + y * y <= r * r;

    return inRectangle || inTriangle || inQuarterCircle;
}

function loadResults() {
    try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (!stored) {
            return [];
        }

        const parsed = JSON.parse(stored);
        return Array.isArray(parsed) ? parsed : [];
    } catch {
        return [];
    }
}

function saveResults(results) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(results));
}

function formatDate(timestamp) {
    return new Intl.DateTimeFormat("ru-RU", {
        dateStyle: "short",
        timeStyle: "medium"
    }).format(new Date(timestamp));
}

function renderResults() {
    const results = loadResults();
    resultsBody.innerHTML = "";

    for (const result of results) {
        const row = document.createElement("tr");

        const xCell = document.createElement("td");
        const yCell = document.createElement("td");
        const rCell = document.createElement("td");
        const hitCell = document.createElement("td");
        const dateCell = document.createElement("td");

        xCell.textContent = result.x;
        yCell.textContent = result.y;
        rCell.textContent = result.r;
        hitCell.textContent = result.hit ? "Да" : "Нет";
        dateCell.textContent = formatDate(result.timestamp);

        hitCell.className = result.hit ? "hit-yes" : "hit-no";

        row.append(xCell, yCell, rCell, hitCell, dateCell);
        resultsBody.appendChild(row);
    }
}

function drawArrow(fromX, fromY, toX, toY) {
    const angle = Math.atan2(toY - fromY, toX - fromX);
    const size = 9;

    ctx.beginPath();
    ctx.moveTo(toX, toY);
    ctx.lineTo(
        toX - size * Math.cos(angle - Math.PI / 6),
        toY - size * Math.sin(angle - Math.PI / 6)
    );
    ctx.lineTo(
        toX - size * Math.cos(angle + Math.PI / 6),
        toY - size * Math.sin(angle + Math.PI / 6)
    );
    ctx.closePath();
    ctx.fill();
}

function drawCanvas(selectedR = 2) {
    const width = canvas.width;
    const height = canvas.height;
    const centerX = width / 2;
    const centerY = height / 2;
    const scale = 52;

    ctx.clearRect(0, 0, width, height);

    function px(x) {
        return centerX + x * scale;
    }

    function py(y) {
        return centerY - y * scale;
    }

    // Область: прямоугольник
    ctx.beginPath();
    ctx.rect(px(0), py(selectedR), selectedR * scale, selectedR * scale);
    ctx.fillStyle = "rgba(70, 130, 180, 0.22)";
    ctx.fill();

    // Область: треугольник
    ctx.beginPath();
    ctx.moveTo(px(-selectedR / 2), py(0));
    ctx.lineTo(px(0), py(selectedR));
    ctx.lineTo(px(0), py(0));
    ctx.closePath();
    ctx.fill();

    // Область: четверть круга
    ctx.beginPath();
    ctx.moveTo(px(0), py(0));
    ctx.arc(px(0), py(0), selectedR * scale, 0, Math.PI / 2);
    ctx.closePath();
    ctx.fill();

    // Контуры области
    ctx.strokeStyle = "#315a7d";
    ctx.lineWidth = 2;

    ctx.beginPath();
    ctx.rect(px(0), py(selectedR), selectedR * scale, selectedR * scale);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(px(-selectedR / 2), py(0));
    ctx.lineTo(px(0), py(selectedR));
    ctx.lineTo(px(0), py(0));
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(px(0), py(0), selectedR * scale, 0, Math.PI / 2);
    ctx.stroke();

    // Оси
    ctx.strokeStyle = "#222";
    ctx.fillStyle = "#222";
    ctx.lineWidth = 1.5;

    ctx.beginPath();
    ctx.moveTo(25, centerY);
    ctx.lineTo(width - 25, centerY);
    ctx.stroke();
    drawArrow(width - 25 - 1, centerY, width - 15, centerY);

    ctx.beginPath();
    ctx.moveTo(centerX, height - 25);
    ctx.lineTo(centerX, 25);
    ctx.stroke();
    drawArrow(centerX, 25 + 1, centerX, 15);

    // Деления и подписи
    ctx.font = "14px Arial";
    ctx.textAlign = "center";
    ctx.textBaseline = "top";

    for (let x = -5; x <= 5; x++) {
        if (x === 0) continue;
        const xPos = px(x);
        if (xPos < 25 || xPos > width - 25) continue;

        ctx.beginPath();
        ctx.moveTo(xPos, centerY - 4);
        ctx.lineTo(xPos, centerY + 4);
        ctx.stroke();

        ctx.fillText(x, xPos, centerY + 7);
    }

    ctx.textAlign = "right";
    ctx.textBaseline = "middle";

    for (let y = -5; y <= 5; y++) {
        if (y === 0) continue;
        const yPos = py(y);
        if (yPos < 25 || yPos > height - 25) continue;

        ctx.beginPath();
        ctx.moveTo(centerX - 4, yPos);
        ctx.lineTo(centerX + 4, yPos);
        ctx.stroke();

        ctx.fillText(y, centerX - 8, yPos);
    }

    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText("X", width - 20, centerY - 13);
    ctx.fillText("Y", centerX + 8, 17);

    // Обозначение R
    ctx.font = "bold 15px Arial";
    ctx.fillText("R", px(selectedR) + 7, py(0) - 14);
    ctx.fillText("R", px(0) + 8, py(selectedR));
    ctx.fillText("R", px(0) + 8, py(-selectedR));

    // Точки из результатов
    const results = loadResults();

    for (const result of results) {
        const x = Number(result.x);
        const y = Number(result.y);
        const r = Number(result.r);

        // Отрисовываем точку только если она помещается в текущую систему координат.
        if (Math.abs(x) <= 5.2 && y >= -5.2 && y <= 5.2) {
            ctx.beginPath();
            ctx.arc(px(x), py(y), 5, 0, Math.PI * 2);
            ctx.fillStyle = result.hit ? "#16803c" : "#b00020";
            ctx.fill();
        }
    }
}

rInput.addEventListener("input", () => {
    const value = normalizeNumber(rInput.value);

    // Разрешаем только число с необязательной десятичной частью.
    if (!/^-?\d*([.,]\d*)?$/.test(rInput.value)) {
        rInput.value = rInput.value.slice(0, -1);
    }

    rInput.value = rInput.value.replace(",", ".");

    const r = Number(value);
    if (Number.isFinite(r) && r >= 1 && r <= 4) {
        drawCanvas(r);
    } else {
        drawCanvas(2);
    }
});

yInput.addEventListener("input", () => {
    if (!/^-?\d*([.,]\d*)?$/.test(yInput.value)) {
        yInput.value = yInput.value.slice(0, -1);
    }

    yInput.value = yInput.value.replace(",", ".");
});

form.addEventListener("submit", event => {
    event.preventDefault();

    const error = validateForm();

    if (error) {
        errorMessage.textContent = error;
        return;
    }

    errorMessage.textContent = "";

    const x = getSelectedX();
    const y = Number(normalizeNumber(yInput.value));
    const r = Number(normalizeNumber(rInput.value));
    const hit = pointIsInside(x, y, r);

    const results = loadResults();

    results.unshift({
        x,
        y,
        r,
        hit,
        timestamp: Date.now()
    });

    saveResults(results);
    renderResults();
    drawCanvas(r);
});

renderResults();
drawCanvas(2);
